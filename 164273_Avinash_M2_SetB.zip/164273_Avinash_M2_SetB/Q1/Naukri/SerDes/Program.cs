﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Naukri.Entities;

namespace Main
{
    class Program
    {
        static void Main(string[] args)
        {

            SerializeData();
            DeserializeData();

        }
        private static void SerializeData()
        {
            List<User> ContactList = new List<User>();
            try
            {
                Console.WriteLine("Enter number of contacts");
                int n = int.Parse(Console.ReadLine());

                for (int index = 0; index < n; index++)
                {
                    User objContact = new User();
                    Console.WriteLine(" details");
                    objContact.Name = Console.ReadLine();
                    objContact.Qualification = Console.ReadLine();
                    objContact.Mobile = Console.ReadLine();
                    objContact.DoB = Console.ReadLine();
                    ContactList.Add(objContact);
                }

                //  Console.WriteLine("Enter the location:");
                // string s = Console.ReadLine();

                FileStream fileStream = new FileStream(@"C: \Users\avichauh\Desktop\Practice\Ser\Main\bin\Debug\f.txt", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, ContactList);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeserializeData()
        {
            try
            {
                //  Console.WriteLine("Enter the location:");
                // string s = Console.ReadLine();
                FileStream fileStream = new FileStream(@"C: \Users\avichauh\Desktop\Practice\Ser\Main\bin\Debug\f.txt", FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<User> obj = (List<User>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (User c in obj)
                {
                    Console.WriteLine("Cell No:" + c.Mobile + "Name:" + c.Name);
                }



            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}

