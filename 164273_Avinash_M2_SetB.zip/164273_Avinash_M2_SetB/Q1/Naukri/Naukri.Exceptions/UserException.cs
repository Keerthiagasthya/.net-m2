﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.Exceptions
{
        public class UserException : ApplicationException
        {

            public UserException() : base()
            {

            }

            public UserException(string message) : base(message)
            {
                // LogToDB();
            }

            public UserException(string message, Exception objEx) : base(message, objEx)
            {

            }

            /*  private void LogToDB()
              {
                  //Log to DB
              }
          */

        }
 }
