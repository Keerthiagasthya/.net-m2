﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.Entities;
using Naukri.Exceptions;

namespace Naukri.DataAccessLayer
{
    public class UserDAL
    {
        public static List<User> objUserList = new List<User>();

        public bool AddUserDAL(User objUser)
        {
            bool userAdded = false;
            try
            {
                objUserList.Add(objUser);
                userAdded = true;
            }
            catch (SystemException objEx)
            {
                throw new UserException(objEx.Message);

            }
            return userAdded;
        }

        public User SearchUserDAL(string city)
        {
            User objUser = null;
            try
            {
                objUser = objUserList.Find(emp => emp.City.Equals(city));
            }

            catch (SystemException objEx)
            {
                throw new UserException(objEx.Message);
            }
            return objUser;
        }

        public List<User> GetAllUserDAL()
        {
            return objUserList;
        }

    }
}
