﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.Entities;
using Naukri.Exceptions;
using Naukri.DataAccessLayer;


namespace Naukri.BusinessLayer
{
    public class UserBL
    {
        private static bool ValidateUser(User objUser)
        {
            StringBuilder objSB = new StringBuilder();
            bool validUser = true;
            if (objUser.Qualification == string.Empty)
            {
                validUser = false;
                objSB.Append(Environment.NewLine + " Qualification has to be BE,ME,MCA");

            }
            if (objUser.City == string.Empty)
            {
                validUser = false;
                objSB.Append(Environment.NewLine + "City has to be Mumbai,Pune,Chennai,Banglore");
            }
            if (objUser.Mobile == string.Empty)
            {
                validUser = false;
                objSB.Append(Environment.NewLine + "Required 10 Digit Mobile Number");

            }
           
            if (validUser == false)
            {
                throw new UserException(objSB.ToString());
            }
            return validUser;
        }

        public static bool AddUserBL(User objUser)
        {
            bool userAdded = false;
            try
            {
                if (ValidateUser(objUser))
                {
                    UserDAL objUserDAL = new UserDAL();
                    userAdded = objUserDAL.AddUserDAL(objUser);
                }
            }
            catch (UserException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userAdded;
        }

        public static User SearchUserBL(string city)
        {
            User objUser;
            try
            {
                UserDAL objUserDAL = new UserDAL();
                objUser = objUserDAL.SearchUserDAL(city);
            }
            catch (UserException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objUser;
        }

        public static List<User> GetAllUserBL()
        {
            List<User> objUserList;
            try
            {
                UserDAL objUserDAL = new UserDAL();
                objUserList = objUserDAL.GetAllUserDAL();


            }
            catch (UserException objEmpMgmtEx)
            {
                throw objEmpMgmtEx;

            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objUserList;

    }     }
}
