﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.Entities
{
    [Serializable]
    public class User
    {
      
        private string _name;

        public string Name

        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }

        }


        private string _qualification;

        public string Qualification

        {
            get
            {
                return _qualification;
            }

            set
            {
                _qualification = value;
            }

        }

        private string _mobile;

        public string Mobile

        {
            get
            {
                return _mobile;
            }

            set
            {
                _mobile = value;
            }

        }


        private string _city;

        public string City

        {
            get
            {
                return _city;
            }

            set
            {
                _city = value;
            }

        }


        private string _dob;

        public string DoB

        {
            get
            {
                return _dob;
            }

            set
            {
                _dob = value;
            }

        }




    }
}
