﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.BusinessLayer;
using Naukri.Exceptions;
using Naukri.Entities;
using Naukri.DataAccessLayer;


namespace Naukri.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter the choice");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());
                switch (taskFlag)
                {
                    case 1:
                        AddUser();
                        break;

                    case 2:
                        SearchUserByCity();
                        break;



                    case 3:
                        ListAllUsers();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
                Console.WriteLine("Do you want to continue? press 'y' ");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y' || choice == 'Y');

        }
            static void PrintMenu()
            {
                Console.WriteLine("Enter Your Choice: \n");
                Console.WriteLine("1 for ADD \n");
                Console.WriteLine("2 for Search \n");
                Console.WriteLine("3 for List \n");
               

            }

        static void AddUser()
        {
            try
            {
                User objUser = new User();
                Console.WriteLine("Enter  Details \n ");
                Console.WriteLine("Enter Name \n");
                objUser.Name = Console.ReadLine();

                Console.WriteLine("Enter Qualification \n");
                objUser.Qualification = Console.ReadLine();

                Console.WriteLine("Enter Mobile No");
                objUser.Mobile = Console.ReadLine();

                Console.WriteLine("Enter City \n ");
                objUser.City = Console.ReadLine();

                Console.WriteLine("Enter DOB \n ");
                objUser.DoB = Console.ReadLine();

                bool userAdded;

                userAdded = UserBL.AddUserBL(objUser);
                if (userAdded)
                {
                    Console.WriteLine("Employee Added Successfully ");
                }
                else
                {
                    Console.WriteLine("Employee Not Added ");
                }

            }
            catch (UserException objEmpMgmtSystmEx)
            {
                Console.WriteLine(objEmpMgmtSystmEx.Message);

            }
        }

        static void SearchUserByCity()
        {

            try

            {
                string city;
                Console.WriteLine("Enter User's city");
                city = Console.ReadLine();
                User objUser;
                objUser = UserBL.SearchUserBL(city);


                if (objUser != null)
                {

                    Console.WriteLine("Employee Details");
                    Console.WriteLine("Name" + objUser.Name);
                    Console.WriteLine("Qualification" + objUser.Qualification);
                    Console.WriteLine("Mobile No" + objUser.Mobile);
                    Console.WriteLine("City " + objUser.City);
                    Console.WriteLine("Dob: " + objUser.DoB);

                }
                else
                {
                    Console.WriteLine("Employee Not Found!!!!");

                }

            }
            catch (UserException objEmpMgmtSystmEx)
            {
                Console.WriteLine(objEmpMgmtSystmEx.Message);
            }

        }

        static void ListAllUsers()
        {
            try
            {
                List<User> objUserList;
                objUserList = UserBL.GetAllUserBL();
                if (objUserList.Count > 0)
                {
                    foreach (User objUser in objUserList)
                    {
                        Console.WriteLine("Employee Details");
                        Console.WriteLine("Name" + objUser.Name);
                        Console.WriteLine("Qualification" + objUser.Qualification);
                        Console.WriteLine("Mobile No" + objUser.Mobile);
                        Console.WriteLine("City " + objUser.City);
                        Console.WriteLine("Dob: " + objUser.DoB);

                    }

                }
                else
                {
                    Console.WriteLine("No record");


                }
            }
            catch (UserException objEmpMgmtSystmEx)
            {
                Console.WriteLine(objEmpMgmtSystmEx.Message);
            }

        }





    }


}


