﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractMath
{
    internal class MathClass : MathOp
    {
        int result;
        public override int AddNumbers(int a,int b)
        {
            result = a + b;
            return result;
        }
        public override int SubNumbers(int c, int d)
        {
            result = c - d;
            return result;
        }
    }
}
