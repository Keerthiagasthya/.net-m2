﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractMath
{
    class Program
    {
        static void Main(string[] args)
        {
            int add, sub;
            MathClass mc = new MathClass();
            Console.WriteLine("Enter First Number:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second Number:");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("------------Addition of Two Number------------");
            add=mc.AddNumbers(num1, num2);
            Console.WriteLine("Addition: "+add);
            Console.WriteLine("-----------Substraction of Two Number------------");
            sub = mc.SubNumbers(num1, num2);
            Console.WriteLine("Subtraction: " + sub);
        }
    }
}
