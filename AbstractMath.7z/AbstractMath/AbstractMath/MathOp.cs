﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractMath
{
    public abstract class MathOp
    {
        public abstract  int AddNumbers(int a, int b);
        public abstract int SubNumbers(int c, int d);
    }
}
