﻿/*********************************************************************
 * File                 : Question 3
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program to serialize and Deserialize book management System.
 * Date                 : 05-Dec-2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entities;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            SerializeData();
            DeserializeData();
        }
        //Serializing the data
        private static void SerializeData()
        {

            //creating object of class Book
            Book objBook = new Book();
            try
            {
                Console.Write("Enter file name \n");
                string file = Console.ReadLine();
                

               
                    //Entering Book Details
                    Console.WriteLine(" Book details");
                    Console.WriteLine("Enter Book Id ");
                    objBook.Id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Book Name ");
                    objBook.Name = Console.ReadLine();
                    Console.WriteLine("Enter Book ISBN Number ");
                    objBook.IsbnNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Book Price ");
                    objBook.Price = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Publisher Name ");
                    objBook.Publisher = Console.ReadLine();
                    Console.WriteLine("Enter Book Pages ");
                    objBook.Pages = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Language ");
                    objBook.Language = Console.ReadLine();
                    Console.WriteLine("Enter Lot ");
                    objBook.Lot = Console.ReadLine();
                    Console.WriteLine("Enter Summary ");
                    objBook.Summary = Console.ReadLine();
                

                FileStream fileStream = new FileStream(file, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, objBook);
                fileStream.Close();
                Console.Write("Suceessful!!!!!! \n");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Deserializing the data
        private static void DeserializeData()
        {
            try
            {
                Console.Write("Enter file name \n");
                string file = Console.ReadLine();
                FileStream fileStream = new FileStream(file, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                Book obj = (Book)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
               
            }
             
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}