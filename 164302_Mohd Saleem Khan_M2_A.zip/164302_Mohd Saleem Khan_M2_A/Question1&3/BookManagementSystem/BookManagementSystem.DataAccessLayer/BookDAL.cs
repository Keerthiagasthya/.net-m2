﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program for book management System
 * Date                 : 05-Dec-2018
 * Layer                : Data Access Layer
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entities;
using BookManagementSystem.Exceptions;

namespace BookManagementSystem.DataAccessLayer
{
    public class BookDAL
    {
        public static List<Book> objBookList = new List<Book>();

        public bool AddBookDAL(Book objBook)
        {
            bool bookAdded = false;
            try
            {
                objBookList.Add(objBook);
                bookAdded = true;
            }
            catch (SystemException objEx)
            {
                throw new BookMngmntExcptn(objEx.Message);
            }
            return bookAdded;
        }

        public Book SearchBookDAL(int id)
        {
            Book objBook = null;
            try
            {
                objBook = objBookList.Find(book => book.Id.Equals(id));
            }
            catch (SystemException objEx)
            {
                throw new BookMngmntExcptn(objEx.Message);
            }
            return objBook;
        }

        public List<Book> GetAllBookDAL()
        {
            return objBookList;
        }

        public bool DeleteBookDAL(int id)
        {
            bool bookDeleted = false;
            try
            {
                Book objBook;
                objBook = objBookList.Find(book => book.Id.Equals(id));
                objBookList.Remove(objBook);
                bookDeleted = true;
            }
            catch (SystemException objEx)
            {
                throw new BookMngmntExcptn(objEx.Message);
            }
            return bookDeleted;
        }
    }
}
