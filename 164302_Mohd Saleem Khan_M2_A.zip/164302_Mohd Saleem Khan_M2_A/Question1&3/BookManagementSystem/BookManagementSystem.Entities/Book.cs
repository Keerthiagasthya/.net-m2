﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program for book management System
 * Date                 : 05-Dec-2018
 * Layer                : Etitiy
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookManagementSystem.Entities
{
    [Serializable]
    public class Book
    {

        private int _id;
        private string _name;
        private int _isbnNo;
        private float _price;
        private string _publisher;
        private int _pages;
        private string _language;
        private string _Lot;
        private string _summary;

        //using setter and getter
        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public int IsbnNo
        {
            get
            {
                return _isbnNo;
            }
            set
            {
                _isbnNo = value;
            }
        }

        public float Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
        public string Publisher
        {
            get
            {
                return _publisher;
            }
            set
            {
                _publisher = value;
            }
        }
        public int Pages
        {
            get
            {
                return _pages;
            }
            set
            {
                _pages = value;
            }

        }
        public string Language
        {
            get
            {
                return _language;
            }
            set
            {
                _language = value;
            }
        }
        


        public string Lot
        {
            get
            {
                return _Lot;
            }
            set
            {
                _Lot = value;
            }
        }
        public string Summary
        {
            get
            {
                return _summary;
            }
            set
            {
                _summary = value;
            }
        }

        

       

    }
}
