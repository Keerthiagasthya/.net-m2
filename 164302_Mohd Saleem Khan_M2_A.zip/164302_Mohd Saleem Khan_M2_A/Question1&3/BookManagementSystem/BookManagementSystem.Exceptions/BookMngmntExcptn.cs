﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program for book management System
 * Date                 : 05-Dec-2018
 * Layer                : Exception
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagementSystem.Exceptions
{
    public class BookMngmntExcptn:ApplicationException
    {
        public BookMngmntExcptn() : base()
        {

        }

        public BookMngmntExcptn(string message) : base(message)
        {

        }

        public BookMngmntExcptn(string message, Exception objEx) : base(message, objEx)
        {

        }
    }
}
