﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program for book management System
 * Date                 : 05-Dec-2018
 * Layer                : Presentation Layer
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entities;
using BookManagementSystem.Exceptions;
using BookManagementSystem.DataAccessLayer;
using BookManagementSystem.BusinessLayer;


namespace BookManagementSystem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Valuable Choice");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());
                switch (taskFlag)
                {
                    case 1:
                        // Calling Add Method
                        AddBook();
                        break;
                    case 2:
                        //Calling Delete Method
                        DeleteBook();
                        break;
                    case 3:
                        //Calling List Method
                        ListBook();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("DO YOU WANT TO CONTINUE?? PRESS 'y' FOR YES AND 'n' FOR NO");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y' || choice == 'Y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("Enter Your Choice \n");
            Console.WriteLine("1 for ADD ");
            Console.WriteLine("2 for Delete ");
            Console.WriteLine("3 for List ");

        }

        //Method to Add Book
        static void AddBook()
        {
            try
            {
                Book objBook = new Book();
                Console.WriteLine("Enter Book Details ");
                Console.WriteLine("Enter Book Id ");
                objBook.Id  = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Book Name ");
                objBook.Name = Console.ReadLine();
                Console.WriteLine("Enter Book ISBN Number ");
                objBook.IsbnNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Book Price ");
                objBook.Price = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter Publisher Name ");
                objBook.Publisher = Console.ReadLine();
                Console.WriteLine("Enter Book Pages ");
                objBook.Pages = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Language ");
                objBook.Language = Console.ReadLine();
                Console.WriteLine("Enter Lot ");
                objBook.Lot = Console.ReadLine();
                if (objBook.Lot.Equals("Java") || objBook.Lot.Equals(".Net") || objBook.Lot.Equals("IMS") || objBook.Lot.Equals("V&V") ||
                    objBook.Lot.Equals("BI") || objBook.Lot.Equals("RDBMS"))
                {
                    Console.WriteLine("Enter further Details ");
                }
                    else {
                    Console.WriteLine("Enter Lot from the List Givern Below \n .Net \n Java \n IMS \n V&V \n BI \n RDBMS ");
                }

                Console.WriteLine("Enter Summary ");
                objBook.Summary = Console.ReadLine();

                bool bookAdded;
                bookAdded = BookBL.AddBookBL(objBook);
                if (bookAdded)
                {
                    Console.WriteLine("Book Added Successfully");
                }
                else
                {
                    Console.WriteLine("Book Not Added!!! ");
                }
            }
            catch (BookMngmntExcptn objBukMgmtSystmEx)
            {
                Console.WriteLine(objBukMgmtSystmEx.Message);
            }

        }
        //Method to Delete Book
        static void DeleteBook()
        {
            try
            {
                bool bookDeleted;
                int id;
                Console.WriteLine("Enter ID");
                id = Convert.ToInt32(Console.ReadLine());
                Book objBook = BookBL.SearchBookBL(id);
                if (objBook != null)
                {
                    bookDeleted = BookBL.DeleteBookBL(id);
                    if (bookDeleted)
                    {
                        Console.WriteLine("Book Data Deleted");
                    }
                    else
                    {
                        Console.WriteLine("Book Data couln't be Deleted");
                    }
                }
                else
                {
                    Console.WriteLine("Book Data is not present");
                }
            }
            catch (BookMngmntExcptn objBukMgmtSystmEx)
            {
                Console.WriteLine(objBukMgmtSystmEx.Message);


            }

        }

        //Method to List all the Books
        static void ListBook()
        {
            try
            {
                List<Book> objBookList;
                objBookList = BookBL.GetAllBookBL();
                if (objBookList != null)
                {
                    Console.WriteLine("Book List");
                    foreach (Book objBook in objBookList)
                    {
                        Console.WriteLine("ID: " + objBook.Id);
                        Console.WriteLine("Name: " + objBook.Name);
                        Console.WriteLine("ISBN NO: " + objBook.IsbnNo);
                        Console.WriteLine("Price: " + objBook.Price);
                        Console.WriteLine("Publisher: " + objBook.Publisher);
                        Console.WriteLine("Number of Pages: " + objBook.Pages);
                        Console.WriteLine("Language: " + objBook.Language);
                        Console.WriteLine("LOT: " + objBook.Lot);
                        Console.WriteLine("Summary: " + objBook.Summary);

                    }
                }
                else
                {
                    Console.WriteLine("Book Record is not present");
                }
            }
            catch (BookMngmntExcptn objBukMgmtSystmEx)
            {
                Console.WriteLine(objBukMgmtSystmEx.Message);
            }

        }
    }
}
