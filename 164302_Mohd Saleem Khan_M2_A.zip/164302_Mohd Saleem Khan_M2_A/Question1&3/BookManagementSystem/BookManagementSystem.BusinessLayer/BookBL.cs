﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program for book management System
 * Date                 : 05-Dec-2018
 * Layer                : Business Layer
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entities;
using BookManagementSystem.Exceptions;
using BookManagementSystem.DataAccessLayer;

namespace BookManagementSystem.BusinessLayer
{
    public class BookBL
    {

        //Doing Validatioon
        public static bool ValidateBook(Book objBook)
        {
            
            StringBuilder objSB = new StringBuilder();
            bool validBook = true;
            if (objBook.Id.ToString().Length != 5)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Invalid Book Id");

            }
            if (objBook.Name == string.Empty)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Book Name Required");

            }
           

            if (validBook == false)
            {
                throw new BookMngmntExcptn(objSB.ToString());
            }

            return validBook;

        }

        public static bool AddBookBL(Book objBook)
        {
            bool bookAdded = false;
            try
            {
                if (ValidateBook(objBook))
                {
                    BookDAL objBookDAL = new BookDAL();
                    bookAdded = objBookDAL.AddBookDAL(objBook);
                }

            }
            catch (BookMngmntExcptn objEmpMgmtEx)
            {
                throw objEmpMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookAdded;

        }

        public static bool DeleteBookBL(int id)
        {
            bool bookDeleted = false;

            try
            {
                if (id > 0)
                {
                    BookDAL objBookDAL = new BookDAL();
                    bookDeleted = objBookDAL.DeleteBookDAL(id);
                }
                else
                {
                    throw new BookMngmntExcptn("Invalid ID");
                }
            }
            catch (BookMngmntExcptn objEmpMgmtEx)
            {
                throw objEmpMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookDeleted;

        }

        public static List<Book> GetAllBookBL()
        {
            List<Book> objBookList;
            try
            {
                BookDAL objBookDAL = new BookDAL();
               objBookList = objBookDAL.GetAllBookDAL();

            }
            catch (BookMngmntExcptn objEmpMgmtEx)
            {
                throw objEmpMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objBookList;

        }

        public static Book SearchBookBL(int id)
        {
            Book objBook;
            try
            {
                BookDAL objBookDAL = new BookDAL();
                objBook = objBookDAL.SearchBookDAL(id);

            }
            catch (BookMngmntExcptn objEmpMgmtEx)
            {
                throw objEmpMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objBook;

        }




    }
}
