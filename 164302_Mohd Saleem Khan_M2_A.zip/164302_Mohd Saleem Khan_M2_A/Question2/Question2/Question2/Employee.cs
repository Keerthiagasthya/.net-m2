﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    //employee class implements IPrintable interface.
    class Employee : IPrintable
    {
        //attribute of employee class.
        private int employeeId;

        public int EmployeeId
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

        private string employeeName;

        public string EmployeeName
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        private string dateOfBirth;

        public string DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }

        public void Print()
        {
            Console.Write("Emloyee Details \n ");
            Console.WriteLine("EmployeeId : {0}\n EmployeeName : {1}\n Gender : {2}\n DateOfBirth : {3} ", employeeId, employeeName, gender, dateOfBirth);
        }
    }
}
