﻿/*********************************************************************
 * File                 : Question_2
 * Author Name          : Mohd Saleem Khan
 * Desc                 : Program to accept Employee Details and Displaying it.
 * Version              : 1.0
 * Date                 : 05-Dec-2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Program
    {
        //Main Method
        static void Main(string[] args)
        {
            //Creating Object of Employee Class
            Employee objemployee = new Employee();
            Console.Write("Enter Emloyee Details \n ");
            Console.WriteLine("Enter Employee Id ");
            objemployee.EmployeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name ");
            objemployee.EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter Employee Gender ");
            objemployee.Gender = Console.ReadLine();
            Console.WriteLine("Enter Employee Date of Birth ");
            objemployee.DateOfBirth = Console.ReadLine();
            objemployee.Print();
            Console.ReadLine();
        }
    }
}
